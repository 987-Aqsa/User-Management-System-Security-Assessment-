const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const db = new sqlite3.Database(':memory:');

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// Create table
db.run("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, password TEXT)");

// Home page
app.get('/', (req, res) => {
    res.render('index');
});

// Signup
app.get('/signup', (req, res) => {
    res.render('signup');
});

app.post('/signup', (req, res) => {
    db.run(`INSERT INTO users (username, password) VALUES ('${req.body.username}', '${req.body.password}')`);
    res.send('User registered! <a href="/login">Login</a>');
});

// Login
app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', (req, res) => {
    db.get(`SELECT * FROM users WHERE username='${req.body.username}' AND password='${req.body.password}'`, (err, row) => {
        if (row) {
            res.send(`Welcome ${row.username}! <a href="/profile">Go to Profile</a>`);
        } else {
            res.send('Invalid login');
        }
    });
});

// Profile
app.get('/profile', (req, res) => {
    res.send('<h1>User Profile</h1><p>This page is vulnerable to XSS.</p>');
});

app.listen(3000, () => console.log('App running on http://localhost:3000'));
